# Security Policy

## Supported Versions

| Library                                                | Version | Supported          |
|--------------------------------------------------------|---------|--------------------|
| [NodeJS](https://github.com/nodejs/node)               | 18.0    | :heavy_check_mark: |
| [Typescript](https://github.com/microsoft/typescript)  | 4.6     | :heavy_check_mark: |
| [React](https://github.com/facebook/react)             | 18.0    | :heavy_check_mark: |
| [Strapi](https://github.com/strapi/strapi)             | 4.2     | :heavy_check_mark: |
| [Ant Design](https://github.com/ant-design/ant-design) | 4.2     | :heavy_check_mark: |
