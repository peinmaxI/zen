import { gql } from '@apollo/client';
import * as Apollo from '@apollo/client';
import * as React from 'react';
import * as ApolloReactComponents from '@apollo/client/react/components';
export type Omit<T, K extends keyof T> = Pick<T, Exclude<keyof T, K>>;
const defaultOptions = {} as const;
export type CardFragment = { __typename?: 'ComponentUiCard', id: string, title?: string | null, subtitle?: string | null, description?: string | null, media?: { __typename?: 'UploadFileEntityResponse', data?: { __typename?: 'UploadFileEntity', id?: string | null, attributes?: { __typename?: 'UploadFile', previewUrl?: string | null, alternativeText?: string | null, url: string } | null } | null } | null };

export type CryptoCurrencyFragment = { __typename?: 'CryptoCurrencyEntity', id?: string | null, attributes?: { __typename?: 'CryptoCurrency', name: string, slug: string, symbol: string, maxSupply?: number | null } | null };

export type EntryFragment = { __typename?: 'ComponentDataEntry', id: string, key?: string | null, value: string };

export type FileFragment = { __typename?: 'UploadFileEntity', id?: string | null, attributes?: { __typename?: 'UploadFile', previewUrl?: string | null, alternativeText?: string | null, url: string } | null };

export type HeadlineFragment = { __typename?: 'ComponentUiHeadline', id: string, title?: string | null, subtitle?: string | null };

export type HomeFragment = { __typename?: 'ComponentPageHome', id: string, pathname: string, hero?: { __typename?: 'ComponentUiCard', subtitle?: string | null, id: string, description?: string | null, title?: string | null, media?: { __typename?: 'UploadFileEntityResponse', data?: { __typename?: 'UploadFileEntity', id?: string | null, attributes?: { __typename?: 'UploadFile', previewUrl?: string | null, alternativeText?: string | null, url: string } | null } | null } | null } | null, features?: Array<{ __typename?: 'ComponentUiCard', id: string, title?: string | null, subtitle?: string | null, description?: string | null, media?: { __typename?: 'UploadFileEntityResponse', data?: { __typename?: 'UploadFileEntity', id?: string | null, attributes?: { __typename?: 'UploadFile', previewUrl?: string | null, alternativeText?: string | null, url: string } | null } | null } | null } | null> | null };

export type LinkFragment = { __typename?: 'ComponentUiLink', id: string, title?: string | null, url: string };

export type MenuFragment = { __typename?: 'MenusMenuEntity', id?: string | null, attributes?: { __typename?: 'MenusMenu', title: string, items?: { __typename?: 'MenusMenuItemRelationResponseCollection', data: Array<{ __typename?: 'MenusMenuItemEntity', id?: string | null, attributes?: { __typename?: 'MenusMenuItem', order?: number | null, createdAt?: Date | null, url?: string | null, title: string, target?: EnumMenusmenuitemTarget | null } | null }> } | null } | null };

export type MenuItemFragment = { __typename?: 'MenusMenuItemEntity', id?: string | null, attributes?: { __typename?: 'MenusMenuItem', order?: number | null, createdAt?: Date | null, url?: string | null, title: string, target?: EnumMenusmenuitemTarget | null } | null };

export type ParagraphFragment = { __typename?: 'ComponentUiParagraph', id: string, value: string };

export type QuoteFragment = { __typename?: 'QuoteEntity', id?: string | null, attributes?: { __typename?: 'Quote', price: number, marketCap: number, volume24h: number, volumeChange24h: number, percentChangeDay: number, percentChangeHour: number, percentChangeMonth: number, percentChangeWeek?: number | null } | null };

export type SeoFragment = { __typename?: 'ComponentSharedSeo', id: string, canonicalURL?: string | null, keywords?: string | null, metaTitle: string, metaViewport?: string | null, metaDescription?: string | null };

export type TabFragment = { __typename?: 'ComponentUiTab', id: string, name: string, pane: { __typename?: 'ComponentUiCard', id: string, title?: string | null, subtitle?: string | null, description?: string | null, media?: { __typename?: 'UploadFileEntityResponse', data?: { __typename?: 'UploadFileEntity', id?: string | null, attributes?: { __typename?: 'UploadFile', previewUrl?: string | null, alternativeText?: string | null, url: string } | null } | null } | null } };

export type ScreenshotMutationVariables = Exact<{
  url: Scalars['String'];
}>;


export type ScreenshotMutation = { __typename?: 'Mutation', screenshot?: string | null };

export type CryptoCurrenciesQueryVariables = Exact<{
  currency?: InputMaybe<Scalars['String']>;
}>;


export type CryptoCurrenciesQuery = { __typename?: 'Query', cryptoCurrencies?: { __typename?: 'CryptoCurrencyEntityResponseCollection', data: Array<{ __typename?: 'CryptoCurrencyEntity', id?: string | null, attributes?: { __typename?: 'CryptoCurrency', name: string, slug: string, symbol: string, maxSupply?: number | null, icon?: { __typename?: 'UploadFileEntityResponse', data?: { __typename?: 'UploadFileEntity', id?: string | null, attributes?: { __typename?: 'UploadFile', previewUrl?: string | null, alternativeText?: string | null, url: string } | null } | null } | null, quotes?: { __typename?: 'QuoteRelationResponseCollection', data: Array<{ __typename?: 'QuoteEntity', id?: string | null, attributes?: { __typename?: 'Quote', price: number, marketCap: number, volume24h: number, volumeChange24h: number, percentChangeDay: number, percentChangeHour: number, percentChangeMonth: number, percentChangeWeek?: number | null } | null }> } | null } | null }> } | null };

export type MeQueryVariables = Exact<{ [key: string]: never; }>;


export type MeQuery = { __typename?: 'Query', me?: { __typename?: 'UsersPermissionsMe', email?: string | null } | null };


      export type PossibleTypesResultData = {
  "possibleTypes": {
    "GenericMorph": [
      "ComponentDataContact",
      "ComponentDataEntry",
      "ComponentDataSet",
      "ComponentPageHome",
      "ComponentSharedMetaSocial",
      "ComponentSharedSeo",
      "ComponentUiCard",
      "ComponentUiGrid",
      "ComponentUiHeadline",
      "ComponentUiLink",
      "ComponentUiParagraph",
      "ComponentUiSection",
      "ComponentUiTab",
      "ComponentUiText",
      "CryptoCurrency",
      "EmailDesignerEmailTemplate",
      "I18NLocale",
      "MenusMenu",
      "MenusMenuItem",
      "Quote",
      "UploadFile",
      "UploadFolder",
      "UsersPermissionsPermission",
      "UsersPermissionsRole",
      "UsersPermissionsUser"
    ]
  }
};
      const result: PossibleTypesResultData = {
  "possibleTypes": {
    "GenericMorph": [
      "ComponentDataContact",
      "ComponentDataEntry",
      "ComponentDataSet",
      "ComponentPageHome",
      "ComponentSharedMetaSocial",
      "ComponentSharedSeo",
      "ComponentUiCard",
      "ComponentUiGrid",
      "ComponentUiHeadline",
      "ComponentUiLink",
      "ComponentUiParagraph",
      "ComponentUiSection",
      "ComponentUiTab",
      "ComponentUiText",
      "CryptoCurrency",
      "EmailDesignerEmailTemplate",
      "I18NLocale",
      "MenusMenu",
      "MenusMenuItem",
      "Quote",
      "UploadFile",
      "UploadFolder",
      "UsersPermissionsPermission",
      "UsersPermissionsRole",
      "UsersPermissionsUser"
    ]
  }
};
      export default result;
    
export const CryptoCurrencyFragmentDoc = gql`
    fragment CryptoCurrency on CryptoCurrencyEntity {
  id
  attributes {
    name
    slug
    symbol
    maxSupply
  }
}
    `;
export const EntryFragmentDoc = gql`
    fragment Entry on ComponentDataEntry {
  id
  key
  value
}
    `;
export const HeadlineFragmentDoc = gql`
    fragment Headline on ComponentUiHeadline {
  id
  title
  subtitle
}
    `;
export const FileFragmentDoc = gql`
    fragment File on UploadFileEntity {
  id
  attributes {
    previewUrl
    alternativeText
    url
  }
}
    `;
export const CardFragmentDoc = gql`
    fragment Card on ComponentUiCard {
  id
  title
  subtitle
  description
  media {
    data {
      ...File
    }
  }
}
    ${FileFragmentDoc}`;
export const HomeFragmentDoc = gql`
    fragment Home on ComponentPageHome {
  id
  pathname
  hero {
    subtitle
    id
    description
    title
    media {
      data {
        ...File
      }
    }
  }
  features {
    ...Card
  }
}
    ${FileFragmentDoc}
${CardFragmentDoc}`;
export const LinkFragmentDoc = gql`
    fragment Link on ComponentUiLink {
  id
  title
  url
}
    `;
export const MenuItemFragmentDoc = gql`
    fragment MenuItem on MenusMenuItemEntity {
  id
  attributes {
    order
    createdAt
    url
    title
    target
  }
}
    `;
export const MenuFragmentDoc = gql`
    fragment Menu on MenusMenuEntity {
  id
  attributes {
    title
    items(sort: "order:ASC") {
      data {
        ...MenuItem
      }
    }
  }
}
    ${MenuItemFragmentDoc}`;
export const ParagraphFragmentDoc = gql`
    fragment Paragraph on ComponentUiParagraph {
  id
  value
}
    `;
export const QuoteFragmentDoc = gql`
    fragment Quote on QuoteEntity {
  id
  attributes {
    price
    marketCap
    volume24h
    volumeChange24h
    percentChangeDay
    percentChangeHour
    percentChangeMonth
    percentChangeWeek
  }
}
    `;
export const SeoFragmentDoc = gql`
    fragment Seo on ComponentSharedSeo {
  id
  canonicalURL
  keywords
  metaTitle
  metaViewport
  metaDescription
}
    `;
export const TabFragmentDoc = gql`
    fragment Tab on ComponentUiTab {
  id
  name
  pane {
    ...Card
  }
}
    ${CardFragmentDoc}`;
export const ScreenshotDocument = gql`
    mutation screenshot($url: String!) {
  screenshot(url: $url)
}
    `;
export type ScreenshotMutationFn = Apollo.MutationFunction<ScreenshotMutation, ScreenshotMutationVariables>;
export type ScreenshotComponentProps = Omit<ApolloReactComponents.MutationComponentOptions<ScreenshotMutation, ScreenshotMutationVariables>, 'mutation'>;

    export const ScreenshotComponent = (props: ScreenshotComponentProps) => (
      <ApolloReactComponents.Mutation<ScreenshotMutation, ScreenshotMutationVariables> mutation={ScreenshotDocument} {...props} />
    );
    

/**
 * __useScreenshotMutation__
 *
 * To run a mutation, you first call `useScreenshotMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useScreenshotMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [screenshotMutation, { data, loading, error }] = useScreenshotMutation({
 *   variables: {
 *      url: // value for 'url'
 *   },
 * });
 */
export function useScreenshotMutation(baseOptions?: Apollo.MutationHookOptions<ScreenshotMutation, ScreenshotMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<ScreenshotMutation, ScreenshotMutationVariables>(ScreenshotDocument, options);
      }
export type ScreenshotMutationHookResult = ReturnType<typeof useScreenshotMutation>;
export type ScreenshotMutationResult = Apollo.MutationResult<ScreenshotMutation>;
export type ScreenshotMutationOptions = Apollo.BaseMutationOptions<ScreenshotMutation, ScreenshotMutationVariables>;
export const CryptoCurrenciesDocument = gql`
    query cryptoCurrencies($currency: String = "USD") {
  cryptoCurrencies(pagination: {limit: 100}) {
    data {
      ...CryptoCurrency
      attributes {
        icon {
          data {
            ...File
          }
        }
        quotes(filters: {currency: {eq: $currency}}, sort: ["createdAt:DESC"]) {
          data {
            ...Quote
          }
        }
      }
    }
  }
}
    ${CryptoCurrencyFragmentDoc}
${FileFragmentDoc}
${QuoteFragmentDoc}`;
export type CryptoCurrenciesComponentProps = Omit<ApolloReactComponents.QueryComponentOptions<CryptoCurrenciesQuery, CryptoCurrenciesQueryVariables>, 'query'>;

    export const CryptoCurrenciesComponent = (props: CryptoCurrenciesComponentProps) => (
      <ApolloReactComponents.Query<CryptoCurrenciesQuery, CryptoCurrenciesQueryVariables> query={CryptoCurrenciesDocument} {...props} />
    );
    

/**
 * __useCryptoCurrenciesQuery__
 *
 * To run a query within a React component, call `useCryptoCurrenciesQuery` and pass it any options that fit your needs.
 * When your component renders, `useCryptoCurrenciesQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useCryptoCurrenciesQuery({
 *   variables: {
 *      currency: // value for 'currency'
 *   },
 * });
 */
export function useCryptoCurrenciesQuery(baseOptions?: Apollo.QueryHookOptions<CryptoCurrenciesQuery, CryptoCurrenciesQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<CryptoCurrenciesQuery, CryptoCurrenciesQueryVariables>(CryptoCurrenciesDocument, options);
      }
export function useCryptoCurrenciesLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<CryptoCurrenciesQuery, CryptoCurrenciesQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<CryptoCurrenciesQuery, CryptoCurrenciesQueryVariables>(CryptoCurrenciesDocument, options);
        }
export type CryptoCurrenciesQueryHookResult = ReturnType<typeof useCryptoCurrenciesQuery>;
export type CryptoCurrenciesLazyQueryHookResult = ReturnType<typeof useCryptoCurrenciesLazyQuery>;
export type CryptoCurrenciesQueryResult = Apollo.QueryResult<CryptoCurrenciesQuery, CryptoCurrenciesQueryVariables>;
export const MeDocument = gql`
    query me {
  me {
    email
  }
}
    `;
export type MeComponentProps = Omit<ApolloReactComponents.QueryComponentOptions<MeQuery, MeQueryVariables>, 'query'>;

    export const MeComponent = (props: MeComponentProps) => (
      <ApolloReactComponents.Query<MeQuery, MeQueryVariables> query={MeDocument} {...props} />
    );
    

/**
 * __useMeQuery__
 *
 * To run a query within a React component, call `useMeQuery` and pass it any options that fit your needs.
 * When your component renders, `useMeQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useMeQuery({
 *   variables: {
 *   },
 * });
 */
export function useMeQuery(baseOptions?: Apollo.QueryHookOptions<MeQuery, MeQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<MeQuery, MeQueryVariables>(MeDocument, options);
      }
export function useMeLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<MeQuery, MeQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<MeQuery, MeQueryVariables>(MeDocument, options);
        }
export type MeQueryHookResult = ReturnType<typeof useMeQuery>;
export type MeLazyQueryHookResult = ReturnType<typeof useMeLazyQuery>;
export type MeQueryResult = Apollo.QueryResult<MeQuery, MeQueryVariables>;