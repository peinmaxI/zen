import { FC } from 'react'
import { Main } from 'src/components/main/Main'

const Home: FC = () => (
  <Main />
)

export { Home as default }
