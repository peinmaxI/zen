import { FC, lazy, memo } from 'react'
import { createBrowserRouter, RouteObject, RouterProvider } from 'react-router-dom'
import { DefaultLayout } from 'src/components/layout'

const Home = lazy<FC>(() => import('./home'))
const NotFound = lazy<FC>(() => import('./not-found'))

const routes: RouteObject[] = [
  {
    path: '',
    element: <DefaultLayout />,
    children: [
      {
        element: <Home />,
        index: true,
        path: '',
      },
      {
        element: <NotFound />,
        path: '*',
      },
    ],
  },
]

export default memo(() => <RouterProvider router={createBrowserRouter(routes)} />)
