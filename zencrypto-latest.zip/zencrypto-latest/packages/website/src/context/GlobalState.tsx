import { default as Hashids } from 'hashids'
import { createContext, FC, PropsWithChildren, useContext, useEffect } from 'react'
import { useLocalStorage, useSet } from 'react-use'

export type ID = number | bigint

type ContextProps = {
  hash: string
  selected: ID[]
  toggle: (id: ID) => void
}

const initialState: ContextProps = {
  selected: [],
  hash: '',
  toggle: value => value,
}

const hashids = new Hashids('', 5, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890')

export const GlobalContext = createContext<ContextProps>(initialState)

export const useGlobalContext = () => useContext(GlobalContext)

export const GlobalProvider: FC<PropsWithChildren> = ({ children }) => {
  const [hash, setHash] = useLocalStorage<string>('selected', '')

  const [ids, { toggle }] = useSet<ID>(new Set(Array.from<ID>(hashids.decode(hash ?? ''))))

  useEffect(() => {
    setHash(hashids.encode(Array.from(ids)))
  }, [ids, setHash])

  return (
    <GlobalContext.Provider
      value={{
        selected: Array.from(ids),
        hash: hash ?? initialState.hash,
        toggle,
      }}
    >
      {children}
    </GlobalContext.Provider>
  )
}
