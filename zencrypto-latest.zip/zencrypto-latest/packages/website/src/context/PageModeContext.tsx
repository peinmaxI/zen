import { createContext, Dispatch, FC, PropsWithChildren, SetStateAction, useState } from 'react'

type PageContext = {
  checked: boolean
  setChecked: Dispatch<SetStateAction<boolean>>
}

const defaultValue: PageContext = {
  checked: false,
  setChecked: checked => !checked,
} as const

const PageModeContext = createContext<PageContext>(defaultValue)

const PageModeProvider: FC<PropsWithChildren> = ({ children }) => {
  const [checked, setChecked] = useState(defaultValue.checked)

  return <PageModeContext.Provider value={{ checked, setChecked }}>{children}</PageModeContext.Provider>
}

export { PageModeContext, PageModeProvider }
