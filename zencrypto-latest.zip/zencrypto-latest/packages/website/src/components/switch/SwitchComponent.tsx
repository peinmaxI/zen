import './SwitchComponent.less'

import { Modal, Switch } from 'antd'
import classNames from 'classnames'
import { default as Hashids } from 'hashids/esm'
import { FC, useContext, useEffect, useState } from 'react'
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom'
import { SvgIcon } from 'src/components/icon'
import { useGlobalContext } from 'src/context/GlobalState'
import { PageModeContext } from 'src/context/PageModeContext'
import { useCryptoCurrenciesQuery } from 'src/graphql'
import { useDarkMode } from 'usehooks-ts'

import { ModalWhenNoCoins } from '../shared-socials/ModalWhenNoCoins'

const SwitchComponent: FC = () => {
  const [modalVisible, setModalVisible] = useState(false)
  const { data } = useCryptoCurrenciesQuery()
  const { checked, setChecked } = useContext(PageModeContext)
  const { isDarkMode } = useDarkMode()
  const [params] = useSearchParams()
  const navigate = useNavigate()
  const { selected } = useGlobalContext()
  const { search } = useLocation()

  useEffect(() => {
    setChecked(!!params.get('cryptocurrencies'))
  }, [params, setChecked])

  const hashids = new Hashids('', 5, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890')

  const urlCoins = data?.cryptoCurrencies?.data.filter(it => selected.includes(Number.parseInt(it.id as string))).map(it => Number.parseInt(it.id as string))

  return (
    <>
      <Switch
        checked={!checked}
        className={classNames('switch', { light: !isDarkMode })}
        unCheckedChildren={<SvgIcon type={'switchBtnWhite'} className={'switch-icon'} />}
        checkedChildren={isDarkMode ? <SvgIcon type={'switchBtn'} className={'switch-icon'} /> : <SvgIcon type={'switchBtnLight'} className={'switch-icon'} />}
        onClick={() => {
          selected.length || search.slice(search.indexOf('='))
            ? navigate({ search: checked ? '' : `cryptocurrencies=${urlCoins && hashids.encode(urlCoins)}` })
            : setModalVisible(true)
        }}
        defaultChecked
      />

      <Modal
        className={'modal'}
        title={false}
        centered
        open={modalVisible}
        getContainer={false}
        footer={false}
        closeIcon={<SvgIcon type={'close'} className={'close-icon'} />}
        onCancel={() => setModalVisible(false)}
      >
        <ModalWhenNoCoins />
      </Modal>
    </>
  )
}

export { SwitchComponent }
