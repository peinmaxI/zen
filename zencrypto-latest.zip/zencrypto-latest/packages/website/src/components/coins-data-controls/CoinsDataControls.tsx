import './CoinsDataControls.less'

import { Row, Typography } from 'antd'
import classNames from 'classnames'
import { FC } from 'react'
import { useDarkMode } from 'usehooks-ts'
const { Text } = Typography

type CoinsDataControlsT = {
  title: string
  isTrue: boolean
  onClick: () => void
}

const CoinsDataControls: FC<CoinsDataControlsT> = ({ title, isTrue, onClick }) => {
  const { isDarkMode } = useDarkMode()

  return (
    <Row align={'middle'} className={classNames('show-zen-item', { 'light': !isDarkMode })} onClick={onClick}>
      <Text className={'show-zen-item-text'}>
        {title}
      </Text>
    </Row>
  )
}

export { CoinsDataControls }