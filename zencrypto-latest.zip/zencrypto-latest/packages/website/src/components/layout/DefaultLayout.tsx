import './DefaultLayout.less'

import { Layout } from 'antd'
import { FC, Suspense } from 'react'
import { Outlet } from 'react-router'
import { HeadMetaTags } from 'src/components/head-meta-tags/HeadMetaTags'
import { Header } from 'src/components/layout/Header'
import { Loader } from 'src/components/layout/Loader'
import { useDarkMode } from 'usehooks-ts'

import { Content } from './Content'

const DefaultLayout: FC = () => {
  const { isDarkMode } = useDarkMode()

  return (
    <Layout className={isDarkMode ? '' : 'light'}>
      <Content>
        <Header />
      </Content>
      <Content>
        <Suspense fallback={<Loader />}>
          <HeadMetaTags />
          <Outlet />
        </Suspense>
      </Content>
    </Layout>
  )
}

export { DefaultLayout }
