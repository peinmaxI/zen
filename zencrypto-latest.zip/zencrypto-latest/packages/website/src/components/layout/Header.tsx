import './Header.less'

import { Row, Typography } from 'antd'
import classNames from 'classnames'
import { FC } from 'react'
import { NavLink } from 'react-router-dom'
import { useBreakpoints } from 'src/components/screen'
import { useDarkMode } from 'usehooks-ts'

import { SvgIcon } from '../icon'
import { SharedComponent } from '../shared-socials/SharedComponent'
import { SwitchComponent } from '../switch/SwitchComponent'

const { Title } = Typography

const Header: FC = () => {
  const { isTablet } = useBreakpoints()
  const { isDarkMode, toggle } = useDarkMode()

  return (
    <nav className={classNames('header', {'light': !isDarkMode})}>
      <Row className={'header-logo'} align={'middle'}>
        <NavLink to={'/'} style={{marginRight: 20}}>
          {isDarkMode
            ? <SvgIcon type={'logoDark'} display={'block'} className={'logo-icon'} />
            : <SvgIcon type={'logoLight'} display={'block'} className={'logo-icon'} />
          }
        </NavLink>
        {isTablet && <SharedComponent />}
      </Row>

      <Title className={'logo-title'}>zencrypto</Title>

      <Row justify={'end'} wrap={false} align={'middle'} className={'header-end'}>
        <>
          {!isTablet && <SharedComponent />}

          {isDarkMode
            ? <SvgIcon type={'light'} onClick={toggle} />
            : <SvgIcon type={'dark'} onClick={toggle} />
          }
        </>
        <SwitchComponent />
      </Row>
    </nav>
  )
}

export { Header }
