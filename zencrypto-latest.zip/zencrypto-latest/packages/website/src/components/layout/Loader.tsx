import './Loader.less'

import { Col, Row, Typography } from 'antd'
import classNames from 'classnames'
import { FC } from 'react'
import { useDarkMode } from 'usehooks-ts'

import { SvgIcon } from '../icon'
const { Title, Text } = Typography

const Loader: FC = () => {
  const { isDarkMode } = useDarkMode()

  return (
    <Row justify={'center'} className={classNames('loader', {'light': !isDarkMode})}>
      <Col span-={24}>
        <Title className={'logo-title'}>zencrypto</Title>
      </Col>

      <Col span={24} className={'loader-center'}>
        {isDarkMode
          ? <SvgIcon type={'logoDark'} display={'block'} className={'logo-icon'} />
          : <SvgIcon type={'logoLight'} display={'block'} className={'logo-icon'} />
        }
        <Title className={'title'}>Welcome to Zencrypto</Title>
        <Text className={'text'}>With Zencrypto you get a secure and fast start with your crypto journey</Text>
      </Col>
    </Row>
  )
}

export { Loader }
