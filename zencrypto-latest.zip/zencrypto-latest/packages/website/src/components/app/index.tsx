import { ApolloClient, ApolloProvider, InMemoryCache } from '@apollo/client'
import { FC } from 'react'
import { GlobalProvider } from 'src/context/GlobalState'
import { PageModeProvider } from 'src/context/PageModeContext'

import introspection from '../../graphql'
import Pages from '../../pages'
import { ErrorBoundary } from './ErrorBoundary'

const client = new ApolloClient({
  uri: '/graphql',
  headers: { Authorization: localStorage.getItem('jwtToken') ? localStorage.getItem('jwtToken') ?? '' : '' },
  connectToDevTools: true,
  queryDeduplication: true,
  cache: new InMemoryCache({
    resultCaching: true,
    possibleTypes: introspection.possibleTypes,
  }),
})

const App: FC = () => (
  <ErrorBoundary>
    <ApolloProvider client={client}>
      <GlobalProvider>
        <PageModeProvider>
          <Pages />
        </PageModeProvider>
      </GlobalProvider>
    </ApolloProvider>
  </ErrorBoundary>
)

export { App }
