import { FC, SVGProps } from 'react'

import { ReactComponent as ArrowDown } from './images/ArrowDown.svg'
import { ReactComponent as ArrowUp } from './images/ArrowUp.svg'
import { ReactComponent as CheckBox } from './images/Checkbox.svg'
import { ReactComponent as Checked } from './images/Checked.svg'
import { ReactComponent as Close } from './images/Close.svg'
import { ReactComponent as Light } from './images/Dark.svg'
import { ReactComponent as Dark } from './images/Light.svg'
import { ReactComponent as LogoDark } from './images/LogoDark.svg'
import { ReactComponent as LogoLight } from './images/LogoLight.svg'
import { ReactComponent as Search } from './images/Search.svg'
import { ReactComponent as Share } from './images/Share.svg'
import { ReactComponent as ShareLightMode } from './images/ShareLightMode.svg'
import { ReactComponent as Star } from './images/Star.svg'
import { ReactComponent as StarSelected } from './images/StarSelected.svg'
import { ReactComponent as SwitchBtn } from './images/SwitchBtn.svg'
import { ReactComponent as SwitchBtnLight } from './images/SwitchBtnLight.svg'
import { ReactComponent as SwitchBtnWhite } from './images/SwitchBtnWhite.svg'

export type IconTypes =
  | 'check'
  | 'checked'
  | 'dark'
  | 'light'
  | 'logoLight'
  | 'logoDark'
  | 'search'
  | 'share'
  | 'shareLightMode'
  | 'star'
  | 'starSelected'
  | 'arrowUp'
  | 'arrowDown'
  | 'close'
  | 'switchBtn'
  | 'switchBtnLight'
  | 'switchBtnWhite'

const icons: { [key: string]: FC<SVGProps<SVGSVGElement>> } = {
  check: CheckBox,
  checked: Checked,
  dark: Dark,
  light: Light,
  logoLight: LogoLight,
  logoDark: LogoDark,
  search: Search,
  share: Share,
  shareLightMode: ShareLightMode,
  star: Star,
  starSelected: StarSelected,
  arrowUp: ArrowUp,
  arrowDown: ArrowDown,
  close: Close,
  switchBtn: SwitchBtn,
  switchBtnLight: SwitchBtnLight,
  switchBtnWhite: SwitchBtnWhite,
} as const

type SvgIconProps = SVGProps<SVGSVGElement> & { type: string, display?: string }

const SvgIcon: FC<SvgIconProps> = ({ type, display, ...svgProps }) => {
  const Icon = icons[type] ?? null
  return Icon && <Icon {...svgProps} style={{cursor: 'pointer', display: display}} />
}

export { SvgIcon }
