import './SharedCards.less'

import { Col } from 'antd'
import classNames from 'classnames'
import { default as Hashids } from 'hashids/esm'
import { FC } from 'react'
import { useLocation } from 'react-router'
import { useBreakpoints } from 'src/components/screen'
import { CoinCard } from 'src/components/shared-cards/CoinCard'
import { useCryptoCurrenciesQuery } from 'src/graphql'
import { useDarkMode } from 'usehooks-ts'

import { Spinner } from '../spinner/Spinner'

const SharedCards: FC = () => {
  const { data, loading } = useCryptoCurrenciesQuery()
  const { isDarkMode } = useDarkMode()
  const { search } = useLocation();
  const { isMobile, isTablet, isDesktop } = useBreakpoints()

  const hashids = new Hashids('', 5, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890')

  const params = search.slice(search.indexOf('=') + 1).split(',')

  const selectedCoins = data?.cryptoCurrencies?.data.filter(coin => coin.id && hashids.decode(params.join('')).includes(Number.parseInt(coin.id as string)))

  return (
    <div
      className={classNames(
        'cards',
        { light: !isDarkMode },
        {'two-cards': selectedCoins && selectedCoins.length <= 2},
        { 'span11': (selectedCoins && selectedCoins.length >= 1 && selectedCoins.length <= 4)},
        { 'span7-less6': (selectedCoins && selectedCoins.length > 4 && selectedCoins.length <= 6)},
        { 'span7-more6': (selectedCoins && selectedCoins.length > 6 && selectedCoins.length <= 9)},
        { 'span5': selectedCoins && selectedCoins.length > 9 && selectedCoins.length <= 12},
        { 'span4': selectedCoins && selectedCoins.length > 12 && selectedCoins.length <= 15},
        { 'span3': selectedCoins && selectedCoins.length > 15},
        { 'more20': selectedCoins && selectedCoins.length > 20},
      )}
    >
      {!selectedCoins
        ? <Spinner />
        : (selectedCoins ?? []).map((coin: any) => {
        const increment: boolean | undefined = coin?.attributes?.quotes?.data[0]?.attributes?.percentChangeDay > 0
        return (
          <Col
            key={coin.id}
            span={selectedCoins && (isMobile && selectedCoins.length >= 1 && selectedCoins.length <= 6)
              ? 24
              : selectedCoins && (isMobile && selectedCoins.length > 6 && selectedCoins.length <= 9)
                ? 11
                : selectedCoins && (selectedCoins.length >= 1 && selectedCoins.length <= 4)
                  ? 11
                  : selectedCoins && (selectedCoins.length > 4 && selectedCoins.length <= 9)
                    ? 7
                    : selectedCoins && isTablet && (selectedCoins.length > 9 && selectedCoins.length <= 12)
                      ? 11
                      : selectedCoins && (selectedCoins.length > 9 && selectedCoins.length <= 12)
                        ? 5
                        : selectedCoins && isTablet && (selectedCoins.length > 12 && selectedCoins.length <= 15)
                          ? 11
                          : selectedCoins && (selectedCoins.length > 12 && selectedCoins.length <= 15)
                            ? 5
                            : selectedCoins && isDesktop && selectedCoins.length > 15
                              ? 11
                              : 4
            }>
            <CoinCard
              id={Number.parseInt(coin.id as string)}
              icon={coin.attributes?.icon?.data?.attributes?.url ?? ''}
              change24h={coin?.attributes?.quotes?.data[0]?.attributes?.percentChangeDay }
              price={coin?.attributes?.quotes?.data[0]?.attributes?.price }
              name={coin.attributes?.name}
              symbol={coin.attributes?.symbol}
              increment={increment}
              highPercentage={increment && (coin?.attributes?.quotes?.data[0]?.attributes?.percentChangeDay - coin?.attributes?.quotes?.data[1]?.attributes?.percentChangeDay) > 10}
              smallPercentage={!increment && (coin?.attributes?.quotes?.data[0]?.attributes?.percentChangeDay - coin?.attributes?.quotes?.data[1]?.attributes?.percentChangeDay) > 10}
            />
          </Col>
        )
      })}
    </div>
  )
}

export { SharedCards }
