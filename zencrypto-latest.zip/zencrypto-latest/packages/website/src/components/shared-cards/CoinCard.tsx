import { Col, Row, Space, Typography } from 'antd'
import classNames from 'classnames'
import { FC } from 'react'
import { CoinIcon } from 'src/components/coin-icon/CoinIcon'
import { SvgIcon } from 'src/components/icon'

import { Price } from '../table/Price'

const { Text } = Typography

type CoinCardT = {
  id: number
  change24h: number
  price: number
  name: string
  symbol: string
  icon: string
  increment: boolean
  highPercentage: boolean
  smallPercentage: boolean
}


const CoinCard: FC<CoinCardT> = ({ icon, id, change24h, price, name, symbol, increment, smallPercentage, highPercentage }) => (
  <div  className={classNames('card', { highPercentage: highPercentage }, { smallPercentage: smallPercentage })}>
    <Row className={'card-top'} align={'middle'} justify={'space-between'}>
      <CoinIcon src={icon} />

      <Space size={3} align={'center'} className={'top-content'}>
        {increment ? <SvgIcon display={'block'} type={'arrowUp'} className={'arrow'} /> : <SvgIcon display={'block'} type={'arrowDown'} className={'arrow'} />}
        <Text style={{ color: increment ? '#06B66A' : '#FF4949', margin: 0 }} className={'change24h'}>
          {change24h.toFixed(2).replace('-','')}{'%'}
        </Text>
      </Space>
    </Row>

    <Row className={'card-bottom'} align={'bottom'} justify={'space-between'}>
      <Col>
        <Text className={'name'}>{name}</Text>
        <Row align={'middle'}><Text className={'price'}>$</Text>{' '}<Price price={price} /></Row>
      </Col>
      <Text className={'symbol'}>{symbol}</Text>
    </Row>
  </div>
)

export { CoinCard }
