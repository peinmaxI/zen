import { Input, Row } from 'antd'
import { ChangeEventHandler, FC } from 'react'
import { SvgIcon } from 'src/components/icon'

type SearchInputT = {
  className: string
  placeholder: string
  query: string
  onChange: ChangeEventHandler<HTMLInputElement>
}
const SearchInput: FC<SearchInputT> = ({ query, onChange, className, placeholder}) => (
  <Row align={'middle'}>
    <SvgIcon type={'search'} className={'search-icon'} />
    <Input
      type='text'
      value={query}
      className={className}
      onChange={onChange}
      placeholder={placeholder}
    />
  </Row>
)

export { SearchInput }
