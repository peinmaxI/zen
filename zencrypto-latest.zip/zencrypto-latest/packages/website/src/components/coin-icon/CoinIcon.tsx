import './CoinIcon.less'

import { FC } from 'react'
import defaultIcon from './CoinIconDefault.svg'

type CoinIconProps = { src: string | undefined }

const CoinIcon: FC<CoinIconProps> = ({ src }) => {
  return <img src={src ? src : defaultIcon} alt={'icon'} className={'icon'} />
}

export { CoinIcon }
