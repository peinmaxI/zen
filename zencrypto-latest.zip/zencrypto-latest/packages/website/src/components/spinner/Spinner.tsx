import './Spinner.less'

import { FC } from 'react'

const Spinner: FC = () => <div className="lds-dual-ring"></div>

export { Spinner }