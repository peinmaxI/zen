import { FC, useEffect, useState } from 'react'
import { Head } from 'react-static'
import { useScreenshotMutation } from 'src/graphql'
import previewImage from './preview.png'

const HeadMetaTags: FC = () => {
  const [screenshotMutation] = useScreenshotMutation()
  const [image, setImage] = useState<string | null>(null)
  const baseUrl = window.location.href
  useEffect(() => {
    baseUrl && screenshotMutation({ variables: { url: baseUrl } })
      .then(result => result.data?.screenshot && setImage(result.data?.screenshot))
  }, [baseUrl, screenshotMutation])

  return (
    <Head>
      <title>ZENCRYPTO</title>
      <meta property="og:title" content="ZENCRYPTO - YOUR CRYPTO ZEN" />
      <meta property="og:type" content="website" />
      <meta property="og:site_name" content={previewImage} />
      <meta property='og:url' content={baseUrl} />
      <meta property='og:description' content={'KEEP TRACK OF YOUR FAVORITE CRYPTOS WITH PEACE IN MIND'} />
      <meta property='og:image' content={previewImage} />

      <meta name='twitter:card' content={'summary_large_image'} />
      <meta property='twitter:url' content={baseUrl} />
      <meta property='twitter:title' content={'ZENCRYPTO'} />
      <meta property='twitter:description' content={'KEEP TRACK OF YOUR FAVORITE CRYPTOS WITH PEACE IN MIND'} />
      <meta name='twitter:image' content={previewImage}/>
    </Head>
  )
}

export { HeadMetaTags }
