import './Main.less'

import { Col, Row } from 'antd'
import axios from 'axios'
import classNames from 'classnames'
import { FC, useEffect, useState } from 'react'
import { useLocation, useSearchParams } from 'react-router-dom'
import { useDebounce, useToggle } from 'react-use'
import { CoinsDataControls } from 'src/components/coins-data-controls/CoinsDataControls'
import { HeadMetaTags } from 'src/components/head-meta-tags/HeadMetaTags'
import { SearchInput } from 'src/components/search-input/SearchInput'
import { SharedCards } from 'src/components/shared-cards/SharedCards'
import { TableComponent } from 'src/components/table/Table'
import { useGlobalContext } from 'src/context/GlobalState'
import { useCryptoCurrenciesQuery } from 'src/graphql'
import { useDarkMode } from 'usehooks-ts'
import { Spinner } from '../spinner/Spinner'

const Main: FC = () => {
  const { hash } = useLocation()
  const { data, loading } = useCryptoCurrenciesQuery()
  const [params] = useSearchParams()
  const [checked, toggle] = useToggle(!!hash)
  const [query, setQuery] = useState('')
  const [debouncedValue, setDebouncedValue] = useState('')
  const [,] = useDebounce(
    () => {
      setDebouncedValue(query)
    },
    500,
    [query],
  )
  const { isDarkMode } = useDarkMode()
  const { selected, hash: hashIds } = useGlobalContext()

  const tableLoading = {
    spinning: loading,
    indicator: <Spinner />,
  }

  return (
    <>
      {!params.get('cryptocurrencies') ? (
        <Row className={classNames('content', { light: !isDarkMode })}>
          <Col className={'content-home'}>
            <Row className={'content-header'} justify={'space-between'} align={'middle'}>
              <Row align={'middle'} justify={'space-between'} style={{ width: '100%' }}>
                <Row align={'middle'} className={'search'}>
                  <SearchInput
                    className={'search-input'}
                    placeholder={'Search crypto'}
                    query={query}
                    onChange={({ currentTarget }) => {
                      return setQuery(currentTarget.value)
                    }}
                  />
                </Row>
                <CoinsDataControls title={!checked ? 'Show only my Zen' : 'Show all'} isTrue={checked} onClick={toggle} />
              </Row>
            </Row>

            {/*<TableComponent*/}
            {/*  dataSource={(data?.cryptoCurrencies?.data ?? [])*/}
            {/*    .filter(*/}
            {/*      item =>*/}
            {/*        (debouncedValue && item?.attributes?.name.toLowerCase().includes(debouncedValue.toLowerCase())) ||*/}
            {/*        item?.attributes?.symbol.toLowerCase().includes(debouncedValue.toLowerCase()),*/}
            {/*    )*/}
            {/*    .filter(it => (checked ? it.id && selected.includes(Number.parseInt(it.id)) : true))*/}
            {/*    .map<CoinMarketCap.CryptoCurrency>(it => ({*/}
            {/*      id: Number.parseInt(it.id as string),*/}
            {/*      name: it.attributes?.name as string,*/}
            {/*      symbol: it.attributes?.symbol as string,*/}
            {/*      icon: it.attributes?.icon?.data?.attributes?.url ?? '',*/}
            {/*      quotes: it.attributes?.quotes?.data,*/}
            {/*      quote: {*/}
            {/*        USD: {*/}
            {/*          volume_24h: it.attributes?.quotes?.data?.[0].attributes?.volume24h ?? 0,*/}
            {/*          price: it?.attributes?.quotes?.data?.[0]?.attributes?.price ?? 0,*/}
            {/*          percent_change_24h: it?.attributes?.quotes?.data?.[0]?.attributes?.percentChangeDay ?? 0,*/}
            {/*          percent_change_1h: it?.attributes?.quotes?.data?.[0]?.attributes?.percentChangeHour ?? 0,*/}
            {/*          market_cap: it?.attributes?.quotes?.data?.[0]?.attributes?.marketCap ?? 0,*/}
            {/*        },*/}
            {/*      },*/}
            {/*    }))}*/}
            {/*  loading={tableLoading}*/}
            {/*/>*/}
          </Col>
        </Row>
      ) : (
        <Row className={classNames('cards-wrap', { light: !isDarkMode })}>
          <HeadMetaTags />
          {/*<SharedCards />*/}
        </Row>
      )}
    </>
  )
}

export { Main }
