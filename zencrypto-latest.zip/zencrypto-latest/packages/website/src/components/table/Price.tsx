import { Statistic } from 'antd'
import { FC } from 'react'

const getSlicedIndex = ((n: number)=> {
  let index;

  if (n > 1) return index = 2
  if (n > 1e-1) return index = 4
  if (n > 1e-2) return index = 5
  if (n > 1e-3) return index = 6
  if (n > 1e-4) return index = 7
  if (n > 1e-5) return index = 8
  if (n > 1e-6) return index = 9

  return index
})

const Price: FC<{ price: number}> = ({price}) => {
  return (
    <Statistic
      value={price.toFixed(getSlicedIndex(price))}
    />
  )
}

export { Price }