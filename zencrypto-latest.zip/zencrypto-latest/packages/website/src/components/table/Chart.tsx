import axios from 'axios'
import moment from 'moment'
import { FC, useEffect, useState } from 'react'
import { Sparklines, SparklinesLine, SparklinesReferenceLine } from 'react-sparklines-typescript'
import { SparklinesReferenceLineTypes } from 'react-sparklines-typescript/build/src/SparklinesReferenceLine'

const startDate = moment().subtract(7, 'days').toISOString();

const Chart: FC<{ color: string, symbol?: string, data?: any[] }> = ({ color, symbol = 'BTC'}) => {
  const [coins, setCoins] = useState([])

  const url = `/api/coinmarketcap/cryptocurrency/quotes/historical?symbol=${symbol}&time_start=${startDate}&interval=12h`

  useEffect(() => {
    coins.length
      ? console.log(coins)
      : axios.get(url).then(result => setCoins(result.data.quotes)).catch(e => console.log(e))
  }, [coins])

  return (
    <Sparklines  data={coins.map((it: any) => it.quote.USD.price)} width={64} height={24}>
      <SparklinesLine color={color} />
      <SparklinesReferenceLine
        type={SparklinesReferenceLineTypes.mean}
        style={{ stroke: color, strokeOpacity: .75, strokeDasharray: '2, 2'}}
      />
    </Sparklines>
  )
}

export { Chart }
