import { FC } from 'react'
import { SvgIcon } from 'src/components/icon'
import { ID, useGlobalContext } from 'src/context/GlobalState'

type StarProps = { id: ID }

const Star: FC<StarProps> = ({ id }) => {
  const { selected, toggle } = useGlobalContext()

  return (
    <SvgIcon
      type={selected.includes(id) ? 'starSelected' : 'star'}
      className={!selected.includes(id) ? 'star-icon' : ''}
      onClick={() => toggle(id)}
    />
  )
}

export { Star }
