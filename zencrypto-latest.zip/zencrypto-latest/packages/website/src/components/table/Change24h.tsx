import { Row, Typography } from 'antd'
import { FC } from 'react'
import { SvgIcon } from 'src/components/icon'

const { Text } = Typography

const Change24h: FC<{ change24h: number }> = ({ change24h }) => {
  return (
    <Row justify={'end'} align={'middle'} >
      {change24h > 0
        ? <SvgIcon type={'arrowUp'} display={'inline-block'} className={'table-arrow-icon'}  />
        : <SvgIcon type={'arrowDown'} display={'inline-block'} className={'table-arrow-icon'} />
      }
      <Text className={'text-change24'} style={{color: change24h > 0 ? '#06B66A' : '#FF4949'}}>
        {change24h.toFixed(2).replace('-','')}{'%'}
      </Text>
    </Row>
  )
}

export { Change24h }