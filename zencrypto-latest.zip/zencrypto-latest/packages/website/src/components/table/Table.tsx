import './Table.less'

import { Col, Row, Table, TableProps, Typography } from 'antd'
import { ColumnProps } from 'antd/es/table'
import classNames from 'classnames'
import moment from 'moment'
import { FC } from 'react'
import { CoinIcon } from 'src/components/coin-icon/CoinIcon'
import { useBreakpoints } from 'src/components/screen'
import { Price } from 'src/components/table/Price'
import { Star } from 'src/components/table/Star'
import { useDarkMode } from 'usehooks-ts'
import { Chart } from './Chart'

import { Change24h } from './Change24h'
import { StatisticComponent } from './StatisticComponent'

const { Text } = Typography

const columns: ColumnProps<CoinMarketCap.CryptoCurrency>[] = [
  {
    title: '',
    dataIndex: 'id',
    render: (id: number) => <Star id={id} />,
  },
  {
    title: '№',
    dataIndex: 'index',
    key: 'index',
    render: (data, record, index) => <Text className={'coin-index'}>{index + 1}.</Text>,
    responsive: ['sm']
  },
  {
    title: 'Token',
    dataIndex: 'token',
    key: 'token',
    render: (data, record) => (
      <>
        <Row align={'middle'} style={{marginBottom: 5}}>
          <CoinIcon src={record.icon} />
          {record.symbol}
        </Row>
        <Text className={'coin-name'}>{record.name}</Text>
      </>
    ),
  },
  {
    title: 'Price,$',
    dataIndex: ['quote', 'USD'],
    key: 'price',
    render: Price,
  },
  {
    title: '24h Change,%',
    dataIndex: ['quote', 'USD', 'percent_change_24h'],
    key: 'change24',
    render: data => <Change24h change24h={data} />
  },
  {
    title: 'Market Cap, $',
    dataIndex: ['quote', 'USD', 'market_cap'],
    key: 'marketcap',
    responsive: ['sm'],
    render: data => <StatisticComponent value={data} />,
  },
  {
    title: '24H Volume, $',
    dataIndex: ['quote', 'USD', 'volume_24h'],
    key: 'volume24',
    responsive: ['sm'],
    render: data => <StatisticComponent value={data} />,
  },
  // {
  //   title: 'Last 7 days',
  //   dataIndex: ['quote', 'USD', 'percent_change_24h'],
  //   key: 'dynamic',
  //   fixed: 'right',
  //   responsive: ['md'],
  //   render: (data, record) => {
  //     return <Chart symbol={record.symbol} color={data > 0 ? '#06B66A' : '#FF4949'} />
  //   },
  // },
]

const TableComponent: FC<Pick<TableProps<CoinMarketCap.CryptoCurrency>, 'dataSource' | 'loading'>> = ({ dataSource = [], loading = false }) => {
  const { isDarkMode } = useDarkMode()
  const { isXl } = useBreakpoints()

  return (
    <Col className={classNames('table-wrap', { light: !isDarkMode })} span={24}>
      <Table
        dataSource={dataSource}
        loading={loading}
        rowKey={record => record.id}
        columns={columns}
        // pagination={{ defaultCurrent: 1, pageSize: 30, total: 100, size: 'small'}}
        pagination={false}
        size={isXl ? 'small' : 'large'}
      />
    </Col>
  )
}

export { TableComponent }
