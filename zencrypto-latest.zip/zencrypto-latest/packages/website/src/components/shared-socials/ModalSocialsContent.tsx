import './ModalContent.less'

import { Input, message, Row } from 'antd'
import classNames from 'classnames'
import { EmailIcon, EmailShareButton, FacebookIcon, FacebookShareButton, TelegramIcon, TelegramShareButton, TwitterIcon, TwitterShareButton } from 'react-share'
import { useBreakpoints } from 'src/components/screen'
import { useDarkMode } from 'usehooks-ts'

const ModalSocialsContent = () => {
  const { isDarkMode } = useDarkMode()
  const { isMobile } = useBreakpoints()

  const shareUrl = window.location.href

  const success = () => message.success('Copied')

  return (
    <Row className={classNames('shared', { light: !isDarkMode })}>
      <Row align={'middle'} className={'shared-icons'}>
        <FacebookShareButton url={shareUrl}>
          <FacebookIcon size={isMobile ? 52 : 64} round />
        </FacebookShareButton>

        <TwitterShareButton url={shareUrl}>
          <TwitterIcon size={isMobile ? 52 : 64} round />
        </TwitterShareButton>

        <TelegramShareButton url={shareUrl}>
          <TelegramIcon size={isMobile ? 52 : 64} round />
        </TelegramShareButton>

        <EmailShareButton url={shareUrl}>
          <EmailIcon size={isMobile ? 52 : 64} round />
        </EmailShareButton>
      </Row>

      <Row align={'middle'} style={{ width: '100%' }} className={'shared-input-group'}>
        <Input.Group>
          <Input
            style={{ width: '100%' }}
            defaultValue={shareUrl}
            onClick={() => {
              navigator.clipboard.writeText(shareUrl)
              success()
            }}
          />
        </Input.Group>
      </Row>
    </Row>
  )
}

export { ModalSocialsContent }
