import './SharedComponent.less'

import { Button, Modal, Row } from 'antd'
import classNames from 'classnames'
import { FC, useState } from 'react'
import { useGlobalContext } from 'src/context/GlobalState'
import { useDarkMode } from 'usehooks-ts'

import { SvgIcon } from '../icon'
import { ModalSocialsContent } from './ModalSocialsContent'
import { ModalWhenNoCoins } from './ModalWhenNoCoins'

const SharedComponent: FC = () => {
  const { isDarkMode } = useDarkMode()
  const { selected } = useGlobalContext()
  const [modalVisible, setModalVisible] = useState(false)

  return (
    <Row className={classNames('modal', { light: !isDarkMode })}>
      <Button type={'link'} onClick={() => setModalVisible(true)} className={'shared-button'}>
        {isDarkMode ? <SvgIcon type={'share'} className={'share-icon'} /> : <SvgIcon type={'shareLightMode'} className={'share-icon'} />}
      </Button>

      <Modal
        title={selected.length ? 'Share it with your friends' : false}
        centered
        open={modalVisible}
        getContainer={false}
        footer={false}
        closeIcon={<SvgIcon type={'close'} className={'close-icon'} />}
        onCancel={() => setModalVisible(false)}
      >
        {selected.length ? <ModalSocialsContent /> : <ModalWhenNoCoins />}
      </Modal>
    </Row>
  )
}

export { SharedComponent }
