import './ModalContent.less'

import { Row, Typography } from 'antd'
import classNames from 'classnames'
import { useDarkMode } from 'usehooks-ts'
const { Paragraph } = Typography

const ModalWhenNoCoins = () => {
  const { isDarkMode } = useDarkMode()

  return (
    <Row justify={'center'} align={'middle'} className={classNames('shared', { 'light': !isDarkMode })}>
      <Paragraph className={'modal-title'}>Select your favorite cryptocurrencies</Paragraph>
    </Row>
  )
}
 export  { ModalWhenNoCoins }
