import { useMediaQuery } from 'react-responsive'

enum Breakpoints {
  XS = 480,
  SM = 576,
  MD = 768,
  LG = 876,
  XL = 1024,
  XXL = 1600,
}

type SizeMap = Readonly<{ [key in keyof typeof Breakpoints]: Breakpoints }>

const sizes: SizeMap = {
  XS: Breakpoints.XS,
  SM: Breakpoints.SM,
  MD: Breakpoints.MD,
  LG: Breakpoints.LG,
  XL: Breakpoints.XL,
  XXL: Breakpoints.XXL,
} as const

type DeviceType = 'mobile' | 'desktop' | 'tablet' | 'xl'

type BreakpointHook = { [key in `is${Capitalize<DeviceType>}`]: boolean } & { sizes: SizeMap }

function useBreakpoints(): BreakpointHook {
  return {
    isMobile: useMediaQuery({ maxWidth: Breakpoints.SM }),
    isDesktop: useMediaQuery({ maxWidth: Breakpoints.LG }),
    isXl: useMediaQuery({ maxWidth: Breakpoints.LG }),
    isTablet: useMediaQuery({ maxWidth: Breakpoints.MD }),
    sizes,
  }
}

export { Breakpoints, useBreakpoints }
