declare namespace CoinMarketCap {
  type CurrencyQuote = { price: number; percent_change_24h: number; market_cap: number; volume_24h: number }
  type CryptoCurrency = {
    id: number
    name: string
    icon?: string
    quote: { [key: string]: CurrencyQuote }
    symbol: string
  }
}
