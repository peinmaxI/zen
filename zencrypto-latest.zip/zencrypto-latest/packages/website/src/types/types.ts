type CurrencyQuote = { price: number; percent_change_24h: number; market_cap: number; volume_24h: number }

export interface CoinI {
  id: number
  symbol: string
  name: string
  quote: { [key: string]: CurrencyQuote }
}