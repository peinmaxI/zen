import { configureReact as configure } from '@bn-digital/vite'

export default configure(
  {},
  {
    sourceMaps: process.env.NODE_ENV !== 'production',
    fonts: {
      google: { families: [{ name: 'Manrope', styles: 'wght@300;400;500;600;700' }], display: 'swap', preconnect: true },
    },
    pwa: {
      mode: 'development',
      base: '/',
      includeManifestIcons: true,
      manifest: {
        name: 'Zencrypto',
        short_name: 'Zencrypto',
        id: '/',
        icons: [
          {
            src: 'pwa128.svg',
            sizes: '128x128',
            type: "image/svg+xml"
          }, {
            src: 'pwa152.svg',
            sizes: '152x152',
            type: 'image/svg+xml'
          }, {
            src: 'pwa144.svg',
            sizes: '144x144',
            type: 'image/svg+xml'
          },
          { src: 'favicon.svg', sizes: '192x192', type: 'image/svg+xml' },
          { src: 'favicon.svg', sizes: '192x192', type: 'image/svg+xml', purpose: 'maskable' },
          { src: 'favicon32.svg', sizes: '32x32', type: 'image/svg+xml', purpose: 'maskable' },
          { src: 'favicon64.svg', sizes: '64x64', type: 'image/svg+xml', purpose: 'maskable' },
          { src: 'pwa.svg', sizes: '192x192', type: 'image/svg+xml', purpose: 'maskable' },
          {
            src: 'pwa-512x512.svg',
            sizes: '512x512',
            type: 'image/svg+xml',
          },
          {
            src: 'pwa-512x512.svg',
            sizes: '512x512',
            type: 'image/svg+xml',
            purpose: 'maskable'
          }
        ],
        theme_color: '#3E3E52',
        categories: ['Cryptocurrency'],
        background_color: '#343C55',
      },
      registerType: 'autoUpdate',
      injectRegister: 'inline',
      devOptions: {
        enabled: true,
      },
    },
  },
)
