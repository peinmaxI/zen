/**
 * `coinmarketcap` middleware.
 */

import '@strapi/strapi'

import axios from 'axios'
import type { Context } from 'koa'

const client = axios.create({
  baseURL: `${process.env.COINMARKETCAP_API_URL}/v1`,
  headers: {
    [`X-CMC_PRO_API_KEY`]: process.env.COINMARKETCAP_API_KEY,
    [`Accept`]: 'application/json',
  },
})

export default () => async (ctx: Context, next: CallableFunction) => {
  if (ctx.url.startsWith('/api/coinmarketcap')) {
    ctx.body = await client.get<{ data: unknown; status: unknown }>(ctx.url.replace('/api/coinmarketcap', '')).then(res => res.data.data)
    return await next()
  } else {
    return await next()
  }
}
