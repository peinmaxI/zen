export default {
  config: {},
  bootstrap(app) {
    console.log(app)
  },
}
