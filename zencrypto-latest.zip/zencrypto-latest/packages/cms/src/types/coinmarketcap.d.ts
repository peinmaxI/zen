declare namespace CoinMarketCap {
  type Quote = {
    price: number
    volume_24h: number
    volume_change_24h: number
    market_cap: number
    percent_change_24h: number
    percent_change_1h: number
    percent_change_7d: number
    percent_change_30d: number
  }
  type CryptoCurrency = {
    id: number
    name: string
    symbol: string
    slug: string
    max_supply: number
    quote: {
      [key in 'USD' | string]: Quote
    }
  }
}
