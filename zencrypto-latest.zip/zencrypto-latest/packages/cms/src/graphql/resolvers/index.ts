import { screenshot } from './screenshot'
import { url } from './upload-file'
import { me } from './user'

const Query = {
  me,
}
const Mutation = { screenshot }
const UploadFile = {
  url,
}
export const resolversConfig = {
  'Mutation.screenshot': {
    auth: false,
  },
}
export default { Query, Mutation, UploadFile }
