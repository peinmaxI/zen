import { printSchema } from 'graphql'

import resolvers, { resolversConfig } from './resolvers'

function generateGraphqlSchema(strapi: Strapi.Strapi): void {
  const schema = getContentApiService(strapi).buildSchema()
  strapi.fs.writeAppFile('./src/graphql/schema.graphqls', printSchema(schema))
  strapi.log.info('[graphql] Schema generated')
}

function getGraphqlPlugin(strapi: Strapi.Strapi): Strapi.Graphql.Plugin {
  return strapi.plugin('graphql')
}

function getExtensionService(strapi: Strapi.Strapi): Strapi.Graphql.ExtensionService {
  return getGraphqlPlugin(strapi).service('extension')
}

function getContentApiService(strapi: Strapi.Strapi): Strapi.Graphql.ContentApiService {
  return getGraphqlPlugin(strapi).service('content-api')
}

function getSchemaExtension(): Strapi.Graphql.ExtensionCallback {
  return ({ nexus }) => {
    return {
      types: [
        nexus.extendType<'Mutation'>({
          type: 'Mutation',
          definition: t => {
            t.field('screenshot', {
              type: 'String',
              args: {
                url: nexus.arg({ type: 'String' }),
              },
            })
          },
        }),
      ],
      resolvers,
      resolversConfig,
    }
  }
}

export { generateGraphqlSchema, getExtensionService, getSchemaExtension }
