/**
 * crypto-currency router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::crypto-currency.crypto-currency');
