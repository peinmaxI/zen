/**
 * crypto-currency service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::crypto-currency.crypto-currency');
