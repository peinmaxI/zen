import axios from 'axios'

export default {
  '0 * * * *': ({ strapi }: Global) => {
    axios
      .get<CoinMarketCap.CryptoCurrency[]>('/api/coinmarketcap/cryptocurrency/listings/latest', {
        baseURL: `http://127.0.0.1:${process.env.PORT ?? 1337}`,
      })
      .then(response =>
        response.data.forEach(({ slug, quote }) => {
          strapi.entityService
            .findMany('api::crypto-currency.crypto-currency', { filters: { slug } })
            .then(result => {
              strapi.entityService.create('api::quote.quote', {
                data: {
                  cryptoCurrency: result[0].id,
                  currency: 'USD',
                  marketCap: quote.USD.market_cap,
                  percentChangeDay: quote.USD.percent_change_24h,
                  percentChangeHour: quote.USD.percent_change_1h,
                  percentChangeMonth: quote.USD.percent_change_30d,
                  percentChangeWeek: quote.USD.percent_change_7d,
                  price: quote.USD.price,
                  volume24h: quote.USD.volume_24h,
                  volumeChange24h: quote.USD.volume_change_24h,
                },
              })
            })
            .catch(console.error)
        }),
      )
    strapi.log.info('[cron] Executing hourly cron job')
  },
}
